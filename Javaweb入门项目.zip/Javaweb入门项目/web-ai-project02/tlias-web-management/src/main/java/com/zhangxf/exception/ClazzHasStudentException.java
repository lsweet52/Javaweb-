package com.zhangxf.exception;

public class ClazzHasStudentException extends RuntimeException{

    public ClazzHasStudentException() {
        super("对不起, 该班级下有学生, 不能直接删除");
    }

    public ClazzHasStudentException(String message) {
        super(message);
    }
}
