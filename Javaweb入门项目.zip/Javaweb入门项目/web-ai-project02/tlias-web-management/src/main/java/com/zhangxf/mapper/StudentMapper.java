package com.zhangxf.mapper;

import com.zhangxf.pojo.ClazzHasStudentCount;
import com.zhangxf.pojo.Student;
import com.zhangxf.pojo.StudentQueryParam;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.MapKey;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;
import java.util.Map;

@Mapper
public interface StudentMapper {

    /**
     * 分页查询
     */
    List<Student> getStudent(StudentQueryParam studentQueryParam);

    /**
     * 添加学生
     */
    void addStudent(Student student);

    /**
     * 根据id查询学生
     */
    Student getStudentById(Integer id);

    /**
     * 根据id修改学生
     */
    void updateStudent(Student student);

    /**
     * 根据id批量删除学生
     */
    void deleteStudentById(List<Integer> ids);

    /**
     * 根据班级统计学生人数
     */
    @MapKey("clazzName")
    List<Map<String, Object>> countStudent();

    /**
     * 根据id查询班级人数
     */
    @Select("select count(*) from student where clazz_id = #{clazzId}")
    Integer countStudentByClazzId(Integer clazzId);
}
