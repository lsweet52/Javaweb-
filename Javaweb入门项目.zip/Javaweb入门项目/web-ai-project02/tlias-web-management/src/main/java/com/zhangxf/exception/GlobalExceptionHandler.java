package com.zhangxf.exception;

import com.zhangxf.pojo.Result;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.View;

/**
 * 全局异常处理器
 */

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    private final View error;

    public GlobalExceptionHandler(View error) {
        this.error = error;
    }

    @ExceptionHandler
    public Result handleException(Exception e) {
        log.error("程序出错啦", e);
        return Result.error("出错了，请重新请求");
    }

    /**
     * 处理班级有学生不能删除的异常
     */
    @ExceptionHandler
    public Result handleClazzHasStudentException(ClazzHasStudentException e){
        log.error("删除班级失败", e);
        return Result.error(e.getMessage());
    }

}