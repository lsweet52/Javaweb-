package com.zhangxf.service;


import com.zhangxf.pojo.EmpLog;

public interface EmpLogService {

    public void insertLog(EmpLog empLog);

}
